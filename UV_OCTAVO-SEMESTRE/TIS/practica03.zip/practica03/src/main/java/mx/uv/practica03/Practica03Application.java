package mx.uv.practica03;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Practica03Application {

	public static void main(String[] args) {
		SpringApplication.run(Practica03Application.class, args);
	}

}
