package mx.uv.practica03;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Practica03ApplicationTests {

	@Test
	void contextLoads() {
	}

}
